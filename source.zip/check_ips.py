#!/usr/bin/env python3
"""
Проверка IP-адресов из geohide_ip_address.txt для записи в hosts.

Для каждого IP скрипт подключается к порту 443, делает TLS-рукопожатие с нужным
доменом (SNI), проверяет сертификат и отправляет HTTP-запрос с заголовком Host.
Любой HTTP-ответ (200, 301, 403, 404...) означает, что домен доступен.

Домены берутся из domens.txt. Каждый раздел ("# Spotify", "# Claude AI" и т.д.)
проверяется отдельно, и для каждого сервиса выбирается свой лучший IP.

Во время работы показывается результат по каждому IP и общий прогресс.

Запуск:
    python check_ips.py                      # все сервисы
    python check_ips.py --section Spotify    # только один сервис
    python check_ips.py --timeout 8 --workers 25
"""
import argparse
import ipaddress
import os
import re
import socket
import ssl
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

if getattr(sys, "frozen", False):  # запуск из .exe (PyInstaller)
    BASE = Path(sys.executable).resolve().parent
else:
    BASE = Path(__file__).resolve().parent
IP_FILE = BASE / "geohide_ip_address.txt"
DOMAINS_FILE = BASE / "domens.txt"
RESULT_FILE = BASE / "hosts_result.txt"

OCTET = r"(?:25[0-5]|2[0-4]\d|1?\d?\d)"
IPV4_RE = re.compile(rf"(?<![\d.])(?:{OCTET}\.){{3}}{OCTET}(?![\d.])")
MAX_PARTIAL_SHOWN = 5
INNER_THREADS = 12  # потоков на проверку доменов одного IP
BAR_WIDTH = 30

# ---------- цвета и вывод ----------
IS_TTY = sys.stdout.isatty()
if IS_TTY and os.name == "nt":
    os.system("")  # включает ANSI-цвета в консоли Windows 10+
GREEN, YELLOW, RED, GRAY, RESET = (
    ("\033[92m", "\033[93m", "\033[91m", "\033[90m", "\033[0m") if IS_TTY else ("",) * 5
)

_lock = threading.Lock()
_bar_visible = False


def emit(text: str = "") -> None:
    """Печатает строку, не ломая строку прогресса."""
    global _bar_visible
    with _lock:
        if _bar_visible:
            sys.stdout.write("\r" + " " * 79 + "\r")
            _bar_visible = False
        print(text, flush=True)


def draw_bar(done: int, total: int, started: float, full_ips: int) -> None:
    global _bar_visible
    if not IS_TTY:
        return
    filled = BAR_WIDTH * done // total if total else BAR_WIDTH
    bar = "#" * filled + "." * (BAR_WIDTH - filled)
    pct = 100 * done // total if total else 100
    elapsed = int(time.time() - started)
    line = (f"[{bar}] {done}/{total} ({pct}%)  "
            f"{elapsed // 60}:{elapsed % 60:02d}  с рабочими сервисами: {full_ips}")
    with _lock:
        sys.stdout.write("\r" + line[:79].ljust(79))
        sys.stdout.flush()
        _bar_visible = True


def clear_bar() -> None:
    global _bar_visible
    if IS_TTY and _bar_visible:
        with _lock:
            sys.stdout.write("\r" + " " * 79 + "\r")
            sys.stdout.flush()
            _bar_visible = False


# ---------- загрузка данных ----------
def load_ips(path: Path) -> list[str]:
    if not path.exists():
        sys.exit(f"Файл не найден: {path}")
    text = "\n".join(l.split("#", 1)[0] for l in
                     path.read_text(encoding="utf-8", errors="ignore").splitlines())
    ips = set()
    for ip in IPV4_RE.findall(text):
        if ipaddress.ip_address(ip).is_global:
            ips.add(ip)
    return sorted(ips, key=ipaddress.ip_address)


def load_sections(path: Path, only: str) -> dict[str, list[str]]:
    """Возвращает {название раздела: [домены]}. only = 'all' или часть названия."""
    if not path.exists():
        sys.exit(f"Файл с доменами не найден: {path}")
    sections: dict[str, list[str]] = {}
    current = None
    for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#"):
            current = line.lstrip("#").strip()
            sections.setdefault(current, [])
            continue
        if current is not None and line not in sections[current]:
            sections[current].append(line)
    sections = {k: v for k, v in sections.items() if v}
    if only.lower() != "all":
        sections = {k: v for k, v in sections.items() if only.lower() in k.lower()}
    if not sections:
        sys.exit(f'В {path.name} нет доменов для раздела "{only}".')
    return sections


# ---------- проверка ----------
def check(ip: str, domain: str, timeout: float, verify: bool) -> bool:
    ctx = ssl.create_default_context()
    if not verify:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((ip, 443), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as tls:
                tls.settimeout(timeout)
                tls.sendall(
                    f"HEAD / HTTP/1.1\r\nHost: {domain}\r\n"
                    f"User-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n".encode()
                )
                return tls.recv(64).startswith(b"HTTP/")
    except Exception:
        return False


def check_ip(ip, sections, timeout, verify):
    """Проверяет один IP по всем сервисам. Возвращает {сервис: множество рабочих доменов}."""
    ok = {name: set() for name in sections}
    with ThreadPoolExecutor(max_workers=INNER_THREADS) as pool:
        # Этап 1: первый домен каждого сервиса
        futs = {pool.submit(check, ip, doms[0], timeout, verify): (name, doms[0])
                for name, doms in sections.items()}
        alive = set()
        for f in as_completed(futs):
            name, dom = futs[f]
            if f.result():
                ok[name].add(dom)
                alive.add(name)
        # Этап 2: остальные домены только там, где этап 1 прошёл
        futs = {pool.submit(check, ip, d, timeout, verify): (name, d)
                for name in alive for d in sections[name][1:]}
        for f in as_completed(futs):
            name, d = futs[f]
            if f.result():
                ok[name].add(d)
    return ip, ok


def format_ip_block(ip, ok, sections, idx, total) -> str:
    width = max(len(n) for n in sections)
    lines = [f"[{idx}/{total}] {ip}"]
    for name, doms in sections.items():
        n, t = len(ok[name]), len(doms)
        if n == t:
            status = f"{GREEN}OK  {RESET}"
        elif n > 0:
            status = f"{YELLOW}PART{RESET}"
        else:
            status = f"{RED}FAIL{RESET}"
        lines.append(f"    {name.ljust(width)} {GRAY}...{RESET} {status} {n}/{t}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--section", default="all",
                    help='сервис (часть названия раздела в domens.txt) или "all"')
    ap.add_argument("--timeout", type=float, default=5.0)
    ap.add_argument("--workers", type=int, default=15,
                    help="сколько IP проверять одновременно")
    ap.add_argument("--no-verify", action="store_true", help="не проверять сертификат")
    args = ap.parse_args()
    verify = not args.no_verify

    sections = load_sections(DOMAINS_FILE, args.section)
    ips = load_ips(IP_FILE)
    if not ips:
        sys.exit(f"В {IP_FILE.name} нет IP-адресов.")

    n_domains = sum(len(v) for v in sections.values())
    print(f"IP-адресов: {len(ips)} | сервисов: {len(sections)} | доменов: {n_domains}")
    print("Сервисы: " + ", ".join(f"{n} ({len(d)})" for n, d in sections.items()))
    print("Проверка запущена...\n")

    results: dict[str, dict[str, set[str]]] = {}
    started = time.time()
    total = len(ips)
    done = 0
    full_ips = 0  # IP, у которых хотя бы один сервис работает полностью
    draw_bar(0, total, started, 0)

    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futs = [pool.submit(check_ip, ip, sections, args.timeout, verify) for ip in ips]
        for f in as_completed(futs):
            ip, ok = f.result()
            results[ip] = ok
            done += 1
            if any(len(ok[n]) == len(d) for n, d in sections.items()):
                full_ips += 1
            emit(format_ip_block(ip, ok, sections, done, total))
            draw_bar(done, total, started, full_ips)
    clear_bar()
    elapsed = int(time.time() - started)
    print(f"\nПроверка завершена за {elapsed // 60}:{elapsed % 60:02d}\n")

    # ---- итоги по сервисам ----
    hosts_lines: list[str] = []
    summary: list[str] = []
    for name, doms in sections.items():
        t = len(doms)
        scores = {ip: len(results[ip][name]) for ip in ips}
        full = [ip for ip in ips if scores[ip] == t]
        part = sorted((ip for ip in ips if 0 < scores[ip] < t), key=lambda x: -scores[x])
        dead = len(ips) - len(full) - len(part)

        print("=" * 56)
        print(f"{name}  ({t} доменов)")
        print("=" * 56)
        print(f"Работают полностью ({t}/{t}): {len(full)}")
        for ip in full:
            print(f"  {GREEN}{ip}{RESET}")
        print(f"Работают частично: {len(part)}")
        for ip in part[:MAX_PARTIAL_SHOWN]:
            print(f"  {YELLOW}{ip}{RESET}  ({scores[ip]}/{t})")
        if len(part) > MAX_PARTIAL_SHOWN:
            print(f"  ... и ещё {len(part) - MAX_PARTIAL_SHOWN}")
        print(f"Не работают: {dead}")

        best = full[0] if full else (part[0] if part else None)
        if best:
            failed = [d for d in doms if d not in results[best][name]]
            print(f"Лучший IP: {best}")
            if failed:
                print(f"  не отвечают через него: {', '.join(failed)}")
            hosts_lines.append(f"# {name} ({best}: {scores[best]}/{t})")
            hosts_lines += [f"{best} {d}" for d in doms if d in results[best][name]]
            hosts_lines.append("")
            summary.append(f"  {name}: {best}  ({scores[best]}/{t})")
        else:
            print("Рабочих IP не найдено.")
            summary.append(f"  {name}: рабочих IP нет")
        print()

    print("=" * 56)
    print("ИТОГ (лучший IP для каждого сервиса)")
    print("=" * 56)
    print("\n".join(summary))

    if hosts_lines:
        RESULT_FILE.write_text("\n".join(hosts_lines) + "\n", encoding="utf-8")
        print(f"\nСтроки для hosts сохранены в {RESULT_FILE.name}")
        print("(в файл попадают только домены, которые реально ответили)")


if __name__ == "__main__":
    try:
        main()
    finally:
        if getattr(sys, "frozen", False):  # чтобы окно не закрылось сразу
            input("\nНажмите Enter для выхода...")
