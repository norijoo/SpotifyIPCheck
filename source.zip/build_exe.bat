@echo off
echo Installing PyInstaller...
python -m pip install pyinstaller
if errorlevel 1 (
    echo.
    echo ERROR: Python or pip not found. Install Python from python.org
    echo and tick "Add python.exe to PATH" during installation.
    pause
    exit /b 1
)
echo Building...
python -m PyInstaller --onefile --name SpotifyIPCheck check_ips.py
echo.
echo Done: dist\SpotifyIPCheck.exe
echo Put it in one folder with domens.txt and geohide_ip_address.txt
pause
